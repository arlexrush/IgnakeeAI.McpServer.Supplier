# Getting Started

## 1. Objetivo
Gu�a r�pida para ejecutar `IgnakeeAI MCP Supplier Server` en local.

## 2. Prerrequisitos
- .NET SDK 8
- Docker y Docker Compose (opcional, recomendado)
- Git
- (Opcional) SQLite / SQL Server seg�n `DataSourceSettings`

## 3. Clonar y preparar
git clone <repo-url> 
cd <repo-folder>

## 4. Configuraci�n
- Copiar `.env.example` a `.env`
- Revisar:
  - `src/IgnakeeAI.McpServer.Supplier.Api/appsettings.json`
  - `src/IgnakeeAI.McpServer.Supplier.Api/appsettings.Development.json`
- Ajustar proveedor de datos (CSV / Excel / EF / ERP)

## 5. Inicializar datos
- Opci�n SQL seed: `seed/seed-catalog.sql`
- Opci�n conectores: CSV/Excel/Odoo/SAP seg�n configuraci�n

## 6. Ejecutar la aplicaci�n
### Opci�n A: .NET local
- dotnet restore 
- dotnet build 
- dotnet run --project src/IgnakeeAI.McpServer.Supplier.Api


### Opci�n B: Docker
- docker compose up --build
(usar `docker-compose.sqlite.yml` si aplica)
## SQLite:
-	docker compose -f docker-compose.yml -f docker-compose.sqlite.yml up -d
## PostgreSQL:
-	docker compose -f docker-compose.yml -f docker-compose.override.yml up -d

## 7. Verificar funcionamiento
- Endpoint MCP: `/mcp`
- Probar tools:
  - `getPrice`
  - `searchAlternatives`
  - `checkAvailability`
  - `getBusinessHours`
- Contrato: `docs/TOOL_CONTRACT.md`

## 8. Ejecutar tests
- dotnet test

Tests clave:
- `PricingToolsTests`
- `AlternativeSearchTests`
- `OdooConnectorTests`

## 9. Soluci�n de problemas
- Revisar configuraci�n de conexi�n (ERP/DB)
- Confirmar variables de entorno
- Validar formato de salida JSON `camelCase`
- Revisar logs de ejecuci�n

## 10. Siguientes pasos
- Arquitectura: `docs/ARCHITECTURE.md`
- Contrato de tools: `docs/TOOL_CONTRACT.md`
