# Arquitectura � IgnakeeAI MCP Supplier Server

## 1. Prop�sito del sistema

`IgnakeeAI.McpServer.Supplier` es un servidor MCP (Model Context Protocol) orientado a cat�logo de proveedor para construcci�n, dise�ado para:

- Exponer herramientas MCP para:
  - consulta de precio (`getPrice`)
  - b�squeda de alternativas (`searchAlternatives`)
  - disponibilidad (`checkAvailability`)
  - datos de atenci�n (`getBusinessHours`)
- Centralizar informaci�n de cat�logo desde m�ltiples fuentes:
  - base de datos local (principal)
  - importaci�n por `CSV`
  - importaci�n por `Excel`
  - sincronizaci�n desde ERP (`Odoo` o `SAP`)
- Ofrecer una integraci�n simple por HTTP (`/mcp`) con salud del servicio (`/health`).

---

## 2. Estilo arquitect�nico

Se aplica una arquitectura por capas con enfoque puertos/adaptadores (hexagonal ligera):

- **Dominio**: entidades y reglas derivadas (`CatalogProduct`, `EffectivePrice`, `DiscountPercent`).
- **Aplicaci�n**: casos de uso y contratos (`CatalogSearchService`, `ICatalogRepository`, `ISupplierConfig`).
- **Infraestructura**: persistencia EF Core, conectores ERP/CSV/Excel, configuraci�n.
- **Entrada MCP/API**: registro de tools MCP y exposici�n HTTP.

### 2.1 Vista de componentes

```mermaid
graph TD
    C["Cliente MCP (agente/LLM)"] --> A["API ASP.NET Core (.NET 8)"]
    A --> M["MCP Endpoint /mcp"]
    A --> H["Health Endpoint /health"]
    M --> T["MCP Tools"]
    T --> S["CatalogSearchService (Application)"]
    S --> R["ICatalogRepository (Puerto)"]
    R --> E["EfCatalogRepository (Adaptador)"]
    E --> D["SupplierCatalogDbContext"]
    D --> DB["SQLite / PostgreSQL / SQL Server / MySQL"]
    A --> AD["Admin Endpoints /admin/* (definidos)"]
    AD --> X["Conectores de sincronizaci�n"]
    X --> DB
```

---

## 3. Estructura de proyectos y responsabilidades

| Proyecto | Responsabilidad principal |
|---|---|
| `IgnakeeAI.McpServer.Supplier.Api` | Bootstrap del host, CORS, health checks, endpoint ra�z y mapeo MCP |
| `IgnakeeAI.McpServer.Supplier.McpTools` | Herramientas MCP y serializaci�n de respuestas |
| `IgnakeeAI.McpServer.Supplier.Application` | Orquestaci�n funcional de b�squeda y contratos de puertos |
| `IgnakeeAI.McpServer.Supplier.Domain` | Modelo de dominio y enums de criterio |
| `IgnakeeAI.McpServer.Supplier.Infrastructure` | EF Core, repositorios, conectores, DI y configuraci�n |
| `IgnakeeAI.McpServer.Supplier.Tests` | pruebas unitarias/integraci�n en memoria (especial foco Odoo y tools) |

---

## 4. Flujo funcional principal

## 4.1 Consulta de precio (`getPrice`)

1. El cliente invoca tool MCP.
2. `PricingTools` delega en `CatalogSearchService`.
3. El servicio intenta:
   - b�squeda exacta por `itemCode`
   - fallback por descripci�n (t�rminos tokenizados)
4. `ICatalogRepository` devuelve `CatalogProduct`.
5. Se calcula precio efectivo (`EffectivePrice`) y se retorna `PriceResult` serializado a JSON.

```mermaid
sequenceDiagram
    participant U as Cliente MCP
    participant P as PricingTools
    participant S as CatalogSearchService
    participant R as ICatalogRepository
    participant D as EF/DB

    U->>P: GetPrice(itemDescription, itemCode)
    P->>S: GetPriceAsync(...)
    alt itemCode informado
        S->>R: FindByCodeAsync(itemCode)
    else sin itemCode o no encontrado
        S->>R: FindByDescriptionAsync(searchTerms)
    end
    R->>D: Query productos activos
    D-->>R: CatalogProduct o null
    R-->>S: resultado
    S-->>P: PriceResult
    P-->>U: JSON (found, unitPrice, contact...)
```

## 4.2 B�squeda de alternativas (`searchAlternatives`)

`CatalogSearchService` aplica estrategia por `SubstitutionCriteria`:

- `Cheaper`: compara contra precio de referencia.
- `Better`: prioriza `QualityRating >= 4`.
- `OnSale`: prioriza productos en oferta.
- `OptimalPack`: minimiza coste y desperdicio para una cantidad requerida.
- `Any`: combina estrategias y deduplica por `ItemCode`.

```mermaid
sequenceDiagram
    participant U as Cliente MCP
    participant A as AlternativeSearchTools
    participant S as CatalogSearchService
    participant R as ICatalogRepository

    U->>A: SearchAlternatives(...)
    A->>S: SearchAlternativesAsync(...)
    alt categor�a no informada
        S->>R: InferCategoryAsync(terms)
    end
    S->>R: Consulta seg�n criterio
    R-->>S: Lista CatalogProduct
    S-->>A: List<AlternativeMatch>
    A-->>U: JSON con alternatives + reason
```

## 4.3 Sincronizaci�n de cat�logo (ERP/CSV/Excel)

Los conectores realizan upsert por `ItemCode` y persisten en cat�logo local.

```mermaid
graph TD
    S1["Origen externo (ERP/CSV/Excel)"] --> S2["Conector correspondiente"]
    S2 --> S3["Mapeo a CatalogProduct"]
    S3 --> S4["Upsert por ItemCode"]
    S4 --> S5["SupplierCatalogDbContext.SaveChanges"]
    S5 --> S6["Cat�logo local disponible para tools MCP"]
```

---

## 5. Modelo de dominio (n�cleo)

Entidad central: `CatalogProduct`.

Campos relevantes para decisiones de compra:

- Identificaci�n: `ItemCode`, `Description`, `Category`, `Keywords`.
- Precio/unidad: `UnitPrice`, `Currency`, `Unit`.
- Oferta: `IsOnSale`, `SalePrice`, `ValidUntil`.
- Calidad/sustituci�n: `QualityRating`, `Specification`, `Presentation`, `IsSubstitute`.
- Log�stica: `AvailableStock`, `LeadTimeDays`.
- Formatos: `PackSize`, `PackPrice`.
- Trazabilidad: `UpdatedAt`, `IsActive`, `ProductUrl`.

Reglas derivadas:

- `EffectivePrice`: usa `SalePrice` si est� activa oferta.
- `DiscountPercent`: ahorro porcentual calculado.

---

## 6. Persistencia y base de datos

`SupplierCatalogDbContext` aplica configuraciones por ensamblado (`ApplyConfigurationsFromAssembly`).

Proveedor de BD configurable en runtime:

- `sqlite` (default)
- `postgresql`
- `sqlserver`
- `mysql`

Configuraci�n en `DependencyInjection`:

- lectura de `DatabaseProvider`
- lectura de `ConnectionStrings:Catalog`
- creaci�n de `DbContext` seg�n provider seleccionado.

�ndices definidos en `CatalogProductConfiguration`:

- `ix_product_category_active` sobre `(Category, IsActive)`
- `ix_product_itemcode` sobre `ItemCode`

Migraciones:

- se ejecutan autom�ticamente al iniciar el host (`db.Database.MigrateAsync()`).

---

## 7. Integraciones externas

## 7.1 Odoo (`OdooConnector`)

- Protocolo: JSON-RPC en `/jsonrpc`.
- Flujo:
  1. autenticaci�n (`common.authenticate`)
  2. lectura (`product.product/search_read`)
  3. mapeo y persistencia local
- Consideraciones:
  - maneja valores `false` de Odoo para campos vac�os
  - permite ampliar campos custom `x_*`.

## 7.2 SAP (`SapConnector`)

- Protocolo: OData / Service Layer.
- Flujo:
  1. `Login`
  2. lectura paginada de `Items`
  3. mapeo y upsert
  4. `Logout`

## 7.3 CSV/Excel

- `CsvCatalogConnector`: delimitador `;`, mapeo por columnas nominales.
- `ExcelCatalogConnector`: hoja `Catalogo` (o primera hoja), columnas fijas A..Q.
- Ambos conectores:
  - hacen upsert por `ItemCode`
  - marcan `UpdatedAt` y `IsActive`.

---

## 8. Contrato MCP expuesto

Tools registradas desde ensamblado `McpTools`:

- `GetPrice(...)`
- `SearchAlternatives(...)`
- `CheckAvailability(...)`
- `GetBusinessHours()`

Endpoint MCP:

- `POST/transport MCP`: `/mcp` (HTTP transport registrado con `.WithHttpTransport()`).

Endpoint health:

- `GET /health`.

Endpoint ra�z informativo:

- `GET /` devuelve metadata del servidor y tools declaradas.

---

## 9. Configuraci�n operativa

## 9.1 `appsettings.json`

Claves relevantes:

- `DatabaseProvider`
- `ConnectionStrings:Catalog`
- `Erp:Provider`
- `Erp:Odoo:*`
- `Erp:Sap:*`

## 9.2 Variables de entorno de proveedor

Consumidas por `SupplierConfig`:

- `SUPPLIER_CONTACT_EMAIL`
- `SUPPLIER_CONTACT_PHONE`
- `SUPPLIER_CONTACT_ADDRESS`
- `SUPPLIER_VENDOR_NAME`
- `SUPPLIER_BUSINESS_HOURS`

---

## 10. Despliegue (contenedor)

Base runtime:

- `mcr.microsoft.com/dotnet/aspnet:8.0`

Puerto expuesto:

- `5100`

Persistencia recomendada por volumen:

- `/app/data` para base SQLite (`/app/data/catalog.db`)

CI/CD:

- `github/workflows/ci.yml`: restore, build, test
- `github/workflows/release.yml`: buildx + push a GHCR por tag `v*`

---

## 11. Calidad, pruebas y validaci�n

Cobertura funcional observable:

- `PricingToolsTests`: precio por c�digo/descripcion/oferta/no encontrado.
- `AlternativeSearchTests`: criterios de sustituci�n.
- `OdooConnectorTests`: happy path, errores auth, cat�logo vac�o, upsert, nullables, comunicaci�n JSON-RPC.

Buenas pr�cticas de validaci�n en pipeline:

1. `dotnet restore`
2. `dotnet build -c Release`
3. `dotnet test -c Release --no-build`
4. build de imagen Docker multi-arquitectura (`amd64`, `arm64`).

---

## 12. Seguridad y hardening recomendado

Para producci�n:

- Restringir CORS (`AllowAnyOrigin` solo para desarrollo).
- Proteger endpoints `/admin/*` con autenticaci�n/autorizaci�n.
- Mover credenciales ERP a secret manager.
- Activar TLS en per�metro (Ingress/Reverse Proxy).
- Registrar auditor�a de sincronizaciones.
- Aplicar rate limiting sobre `/mcp` y `/admin/*`.
- A�adir timeouts/retries con pol�ticas de resiliencia en `HttpClient`.

---

## 13. Riesgos y observaciones t�cnicas actuales

Observaciones detectadas en estado actual del c�digo:

1. `AdminCatalogEndPoint` est� implementado, pero no se observa llamado a `MapAdminCatalogEndpoints()` en `Program.cs`; por tanto, esos endpoints no quedar�an expuestos hasta mapearse expl�citamente.
2. El `Dockerfile` referencia `COPY --from=publish` sin etapa `publish` declarada; la publicaci�n se ejecuta en la etapa `build`. Conviene corregir antes del release.
3. `ISupplierConfig` define propiedades no-null, mientras `SupplierConfig` expone algunas como nullable; revisar para coherencia de nullability.

Estas observaciones no invalidan la arquitectura, pero s� afectan operatividad/release si no se ajustan.

---

## 14. Runbook m�nimo de operaci�n

## 14.1 Arranque local

1. Configurar `appsettings.json` (BD + ERP opcional).
2. Exportar variables `SUPPLIER_*`.
3. Iniciar API.
4. Verificar:
   - `GET /health` => healthy
   - `GET /` => metadata
   - transporte MCP en `/mcp`

## 14.2 Sincronizaci�n de cat�logo

- ERP: `POST /admin/sync/erp`
- Excel: `POST /admin/sync/excel` (`form-data`, `file`)
- CSV: `POST /admin/sync/csv` (`form-data`, `file`)
- M�tricas b�sicas: `GET /admin/catalog/stats`

---

## 15. Evoluci�n recomendada (roadmap)

1. Exponer OpenAPI para endpoints admin.
2. Programar sincronizaciones peri�dicas (`IHostedService` o scheduler externo).
3. A�adir multi-tenant (cat�logo por proveedor).
4. Incorporar cache para b�squedas frecuentes.
5. Telemetr�a estructurada (OpenTelemetry + trazas de tool).
6. Versionado expl�cito de contrato MCP y compatibilidad hacia atr�s.

---

## 16. Decisiones arquitect�nicas clave

- Cat�logo local como fuente de lectura de baja latencia para tools MCP.
- Integraciones ERP desacopladas mediante `IErpConnector`.
- L�gica de negocio centralizada en `CatalogSearchService`.
- Persistencia abstracta por `ICatalogRepository`.
- Extensibilidad por nuevos conectores sin modificar dominio.

---

## 17. Resumen ejecutivo

La soluci�n est� preparada para operar como servidor MCP de proveedor en .NET 8, con arquitectura limpia, m�ltiples fuentes de cat�logo y despliegue contenedorizado.  
Para un despliegue productivo s�lido, deben cerrarse los tres puntos del apartado de observaciones t�cnicas y aplicar hardening de seguridad/operaci�n.
